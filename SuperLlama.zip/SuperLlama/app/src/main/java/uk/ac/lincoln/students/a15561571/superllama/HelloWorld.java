package uk.ac.lincoln.students.a15561571.superllama;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

//  steeeep 1, add the imports
import android.view.View;
import android.widget.*;

public class HelloWorld extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hello_world);
    }// end OnCreate

    public void textChangeButton( View view) {
        //local var declarations
        String debugTest;

        //creating textview control object
        TextView tvl = (TextView)findViewById(R.id.changeText);

        tvl.setVisibility(View.VISIBLE);

        for (int i = 0; i < 5 ; i++)
        {
            debugTest = "testing" + i;
        }//end for

        tvl.setText("Finished Looping!");
    }//end public void textChangeButton

    public void changeTextRed(View view){

        TextView tvl = (TextView)findViewById(R.id.changeText);

    }//end changeTextRed

    public void changeTextBlack(View view){
        TextView tvl = (TextView)findViewById(R.id.changeText);

        //tvl.setTextColor(Color.rgb(200,0,0));
    }//end changeTextBlack
}//end public class HelloWorld
